//
//  MGPASettings.h
//  kgvmp
//
//  Created by Jetcai on 2022/5/7.
//  Copyright © 2022 mgpa. All rights reserved.
//

#ifndef MGPASettings_h
#define MGPASettings_h


/**
 应用版本信息
 */
#define GCLOUD_VERSION_MGPA "GCLOUD_VERSION_MGPA_1.2.6.6"

#endif /* MGPASettings_h */
