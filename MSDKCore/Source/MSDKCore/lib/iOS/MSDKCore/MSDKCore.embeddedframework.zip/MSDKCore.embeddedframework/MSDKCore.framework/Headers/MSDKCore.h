//
//  MSDKCore.h
//  MSDKCore
//
//  Created by brightwan on 2018/3/20.
//  Copyright © company. All rights reserved.
//
 
#import <MSDKCore/MSDK.h>
#import <MSDKCore/MSDKApplicationDelegate.h>
#import <MSDKCore/MSDKCompatLayer.h>
#import <MSDKCore/MSDKConfig.h>
#import <MSDKCore/MSDKConfigManager.h>
#import <MSDKCore/MSDKCore.h>
#import <MSDKCore/MSDKCrash.h>
#import <MSDKCore/MSDKCrashDelegate.h>
#import <MSDKCore/MSDKDefine.h>
#import <MSDKCore/MSDKError.h>
#import <MSDKCore/MSDKFileUtils.h>
#import <MSDKCore/MSDKFriend.h>
#import <MSDKCore/MSDKFriendDelegate.h>
#import <MSDKCore/MSDKGame.h>
#import <MSDKCore/MSDKGameDelegate.h>
#import <MSDKCore/MSDKGroup.h>
#import <MSDKCore/MSDKGroupDelegate.h>
#import <MSDKCore/MSDKJsonManager.h>
#import <MSDKCore/MSDKJsonReader.h>
#import <MSDKCore/MSDKJsonWriter.h>
#import <MSDKCore/MSDKLifeCycleAble.h>
#import <MSDKCore/MSDKObserverManager.h>
#import <MSDKCore/MSDKLifeCycleManager.h>
#import <MSDKCore/MSDKLog.h>
#import <MSDKCore/MSDKLogUtil.h>
#import <MSDKCore/MSDKLogin.h>
#import <MSDKCore/MSDKLoginDelegate.h>
#import <MSDKCore/MSDKMacroExpand.h>
#import <MSDKCore/MSDKMacros.h>
#import <MSDKCore/MSDKNetworkUtils.h>
#import <MSDKCore/MSDKNotice.h>
#import <MSDKCore/MSDKProtocol.h>
#import <MSDKCore/MSDKPush.h>
#import <MSDKCore/MSDKPushDelegate.h>
#import <MSDKCore/MSDKReport.h>
#import <MSDKCore/MSDKReportDelegate.h>
#import <MSDKCore/MSDKSingleton.h>
#import <MSDKCore/MSDKSynthesizeSingleton.h>
#import <MSDKCore/MSDKTools.h>
#import <MSDKCore/MSDKUtilsIOS.h>
#import <MSDKCore/MSDKWebView.h>
#import <MSDKCore/MSDKWebViewDelegate.h>
#import <MSDKCore/MSDKLBS.h>
#import <MSDKCore/MSDKLBSDelegate.h>
#import <MSDKCore/MSDKExtend.h>
#import <MSDKCore/MSDKAccount.h>
#import <MSDKCore/MSDKSensitivityDelegate.h>
#import <MSDKCore/MSDKSensitive.h>
#import <MSDKCore/MSDKSensitiveOc.h>



#define MSDKCore_Version_String "5.30.002.7208"
#define MSDKCore_Version_Int 53002
