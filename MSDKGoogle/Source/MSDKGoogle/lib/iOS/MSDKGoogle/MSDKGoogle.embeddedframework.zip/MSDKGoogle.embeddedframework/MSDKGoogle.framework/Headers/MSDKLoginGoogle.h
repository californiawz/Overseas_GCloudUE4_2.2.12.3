///*
/*!
 * @Header MSDKLoginGoogle.h
 * @Author 小白
 * @Version 1.0.0
 * @Date 2019/7/9
 * @Abstract 文件功能的声明
 *
 * @Module iTOP
 *
 * Copyright © company. All rights reserved.
 */

#import <Foundation/Foundation.h>
#import <MSDKCore/MSDKCore.h>
#import <GoogleSignIn/GoogleSignIn.h>

#define MSDK_GOOGLE_CHANNEL_ID     6

#define MSDK_GOOGLE_CHANNEL        "Google"
#define MSDK_GOOGLE_PLUGIN_NAME    "MSDKGoogle"


/** 登录模块
 * - 命名规则：固定为 MSDKLogin + 渠道，如：MSDKLoginGarena
 * - 必须实现 MSDKLoginDelegate
 * - 必须实现单例模块，建议使用 SYNTHESIZE_SINGLETON_FOR_CLASS_HEADER + SYNTHESIZE_SINGLETON_FOR_CLASS_HEADER 宏处理
 */
@interface MSDKLoginGoogle : NSObject <MSDKLoginDelegate>

@property(atomic, strong) GIDConfiguration *msdkGIDConfiguration;
/** 插件必须是的单例的，建议使用 MSDK 提供的宏定义进行处理
 * 单例宏处理 - 头文件部分
 */
SYNTHESIZE_SINGLETON_FOR_CLASS_HEADER(MSDKLoginGoogle)


@end


