///*
/*!
 * @Header MSDKGoogle.h
 * @Author Rockey
 * @Version 1.0.0
 * @Date 2019/7/9
 *
 * @Module iTOP
 *
 * Copyright © company. All rights reserved.
 */

#import <UIKit/UIKit.h>

#define MSDKGoogle_Version_String "5.30.001.7206"
#define MSDKGoogle_Version_Int 53001
#define GCLOUD_VERSION_MSDK_GOOGLE "GCLOUD_VERSION_MSDK_GOOGLE_5.30.001"

