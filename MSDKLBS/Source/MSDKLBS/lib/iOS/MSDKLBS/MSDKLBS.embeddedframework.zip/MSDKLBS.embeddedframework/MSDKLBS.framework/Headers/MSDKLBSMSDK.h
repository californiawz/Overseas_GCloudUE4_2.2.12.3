///*
/*!
 * @Header MSDKLBSMSDK.h
 * @Author waylenzhang
 * @Version 1.0.0
 * @Date 2019/5/16
 * @Abstract LBS插件模块
 *
 * @Module MSDKV5
 *
 * Copyright © company. All rights reserved.
 */

#import <Foundation/Foundation.h>
#import <MSDKCore/MSDKCore.h>

using namespace std;

@interface MSDKLBSMSDK : NSObject

+ (instancetype)sharedInstance;

@end
