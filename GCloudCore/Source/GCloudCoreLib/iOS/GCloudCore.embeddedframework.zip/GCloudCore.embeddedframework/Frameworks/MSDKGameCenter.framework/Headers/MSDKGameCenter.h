/*!
* Copyright (C) 2019 THL A29 Limited, a company. All rights reserved.
*/

#import <MSDKGameCenter/MSDKLoginGameCenter.h>

#define MSDKGameCenter_Version_String "5.21.001.5880"
#define MSDKGameCenter_Version_Int 52101
#define GCLOUD_VERSION_MSDK_GAMECENTER "GCLOUD_VERSION_MSDK_GAMECENTER_5.21.001"
