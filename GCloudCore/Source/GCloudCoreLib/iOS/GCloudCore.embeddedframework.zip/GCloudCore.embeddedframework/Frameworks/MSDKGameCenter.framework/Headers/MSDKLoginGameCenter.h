/*!
* Copyright (C) 2019 THL A29 Limited, a company. All rights reserved.
*/

#import <Foundation/Foundation.h>
#import <MSDKCore/MSDKCore.h>

// GameCenter 渠道定义
#define MSDK_GAMECENTER_CHANNEL_ID 5
// JSON 键名
#define MSDK_JSON_PUBLIC_KEY_URL        "public_key_url"
#define MSDK_JSON_SIGNATURE             "signature"
#define MSDK_JSON_BUNDLE_ID             "bundle_id"
#define MSDK_JSON_PLAYER_ID             "player_id"
#define MSDK_JSON_SALT                  "salt"
#define MSDK_JSON_USER_NAME             "user_name"
#define MSDK_JSON_IOS_DATA              "ios_data"
#define MSDK_JSON_TIMESTAMP             "timestamp"




/**
 * GameCenter 登录插件
 */
@interface MSDKLoginGameCenter : NSObject <MSDKLoginDelegate>

@end
