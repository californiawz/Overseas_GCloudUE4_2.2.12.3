//
//  MSDKGameDelegate.h
//  MSDKCore
//
//  Created by lamarzhang(张庆贺) on 2018/6/18.
//  Copyright © company. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import "MSDKGameManager.h"

@protocol MSDKGameDelegate <NSObject>

//- (void)setup:(MSDKGameCallback *)callback;
//
//- (void)showLeaderBoard:(const string &)board callback:(MSDKGameCallback *)callback;
//
//- (void)setScore:(int)score board:(const string &)board callback:(MSDKGameCallback *)callback;
//
//- (void)showAchievement:(MSDKGameCallback *)callback;

@end
