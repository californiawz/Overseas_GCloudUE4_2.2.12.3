///*
/*!
 * @Header MSDKSensitivity.h
 * @Author lamarzhang(张庆贺)
 * @Version 1.0.0
 * @Date 2020/7/30
 * @Abstract 文件功能的声明
 *
 * @Module iTOP
 *
 * Copyright © 2020 company. All rights reserved.
 */

#import <Foundation/Foundation.h>
#import <MSDKSensitivity/MSDKSensitivityUtils.h>


#define MSDKSensitivity_Version_String "5.12.000.7208"
#define MSDKSensitivity_Version_Int 51200
#define GCLOUD_VERSION_MSDK_SENSITIVITY "GCLOUD_VERSION_MSDK_SENSITIVITY_5.12.000"
