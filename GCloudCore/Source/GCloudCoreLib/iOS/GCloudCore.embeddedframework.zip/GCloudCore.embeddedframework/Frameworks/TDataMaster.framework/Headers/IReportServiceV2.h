
#ifndef IReportServiceV2_h
#define IReportServiceV2_h

#include "IReportService.h"
#include "ITDataMasterV2.h"

GCLOUD_PLUGIN_NAMESPACE
_USE_TDM_Name_Space

class IReportServiceV2 : public IReportService
{
protected:
    virtual ~IReportServiceV2(){}

public:
    virtual int GetVersion() { return 2; }

public:
    virtual IEventData* CreateEventData() = 0;
    virtual void DestroyEventData(IEventData*& eventData) = 0;
    virtual void ReportLoginV2(int platform, const char* openid, const TDM::IEventData *evnetData) = 0;
};

GCLOUD_PLUGIN_NAMESPACE_END

#endif /* IReportServiceV2_h */
