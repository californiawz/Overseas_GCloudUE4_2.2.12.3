//
//  TDMIDFA.h
//  TDMIDFA
//
//  Created by junhui on 2020/8/25.
//  Copyright © 2020 TDataMaster. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for TDMIDFA.
FOUNDATION_EXPORT double TDMIDFAVersionNumber;

//! Project version string for TDMIDFA.
FOUNDATION_EXPORT const unsigned char TDMIDFAVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TDMIDFA/PublicHeader.h>

@interface TDMIDFA : NSObject

@end



