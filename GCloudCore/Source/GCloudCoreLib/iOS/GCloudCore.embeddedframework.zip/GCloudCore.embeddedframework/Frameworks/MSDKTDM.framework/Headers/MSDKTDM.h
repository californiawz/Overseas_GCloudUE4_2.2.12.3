/*!
* Copyright (C) 2019 THL A29 Limited, a company. All rights reserved.
*/

#import <MSDKTDM/MSDKReportTDM.h>


#define MSDKTDM_Version_String "5.29.000.6677"
#define MSDKTDM_Version_Int 52900
#define GCLOUD_VERSION_MSDK_TDM "GCLOUD_VERSION_MSDK_TDM_5.29.000"


