///*
/*!
 * @Header MSDKFriendSMS.h
 * @Author yvonneycai
 * @Version 1.0.0
 * @Date 2019/11/14
 * @Abstract 文件功能的声明
 *
 * @Module iTOP
 *
 * Copyright © company. All rights reserved.
 */

#import <Foundation/Foundation.h>
#import <MSDKCore/MSDKCore.h>

// 日志上报类型
#define SMS_FRIEND_REPORT_TYPE "SMSFriend"

/**
 * SMS 好友插件
 */
@interface MSDKFriendSMS : NSObject <MSDKFriendDelegate>

/**
 * 单例宏处理 - 头文件部分
 */
SYNTHESIZE_SINGLETON_FOR_CLASS_HEADER(MSDKFriendSMS)

@end
