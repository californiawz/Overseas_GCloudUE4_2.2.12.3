/*!
 * Copyright (C) 2019 THL A29 Limited, a company. All rights reserved.
 */

#import <Foundation/Foundation.h>
#import <MSDKCore/MSDKCore.h>

// 日志上报类型
#define SYSTEM_FRIEND_REPORT_TYPE "SystemFriend"

/**
 * System 好友插件
 */
@interface MSDKFriendSystem : NSObject <MSDKFriendDelegate>

/**
 * 单例宏处理 - 头文件部分
 */
SYNTHESIZE_SINGLETON_FOR_CLASS_HEADER(MSDKFriendSystem)

@end
