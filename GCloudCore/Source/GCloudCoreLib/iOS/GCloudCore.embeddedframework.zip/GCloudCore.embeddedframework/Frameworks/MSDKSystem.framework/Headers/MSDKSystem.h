/*!
 * Copyright (C) 2019 THL A29 Limited, a company. All rights reserved.
 */

#import <UIKit/UIKit.h>

#define MSDKSystem_Version_String "5.27.001.6215"
#define MSDKSystem_Version_Int 52701
#define GCLOUD_VERSION_MSDK_SYSTEM "GCLOUD_VERSION_MSDK_SYSTEM_5.27.001"
