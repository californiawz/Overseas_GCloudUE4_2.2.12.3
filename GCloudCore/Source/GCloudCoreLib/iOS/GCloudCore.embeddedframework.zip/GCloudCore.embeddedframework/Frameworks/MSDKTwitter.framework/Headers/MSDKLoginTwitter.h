/*!
* Copyright (C) 2019 THL A29 Limited, a company. All rights reserved.
*/

#import <Foundation/Foundation.h>
#import <MSDKCore/MSDKCore.h>

// Twitter 渠道名
#define MSDK_TWITTER_CHANNEL_ID 9
#define MSDK_TWITTER_CHANNEL "Twitter"

// 日志上报类型
#define MSDK_TWITTER_LOGIN_REPORT_TYPE "TwitterLogin"

/**
 * Twitter 登录插件
 */
@interface MSDKLoginTwitter : NSObject <MSDKLoginDelegate>

/**
 * MSDK 中插件必须是单例的
 * 单例宏处理 - 头文件部分
 */
SYNTHESIZE_SINGLETON_FOR_CLASS_HEADER(MSDKLoginTwitter)

@end
