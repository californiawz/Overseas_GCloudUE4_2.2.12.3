//
//  TwitterWeb.h
//  TwitterWebKit
//
//  Created by yvonneycai on 2019/12/13.
//  Copyright © 2019 MSDK. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import "TwitterWrapperSession.h"


@interface TwitterWeb : NSObject


/**
*  The current version of this kit.
*/
+ (NSString *) getVersion;


/**
 *  Triggers user authentication with Twitter.
 *
 *  This method will present UI to allow the user to log in if there are no saved Twitter login credentials.
 *  This method is equivalent to calling loginWithMethods:completion: with TWTRLoginMethodAll.
 *
 *  @param viewController The current view controller when use web login, set it nil othersize
 *  @param url The url when use web login, set it nil othersize
 *  @param completion The completion block will be called after authentication is successful or if there is an error.
 *  @warning This method requires that you have set up your `consumerKey` and `consumerSecret`.
 */
+ (void)logInWithCompletion:(UIViewController *)viewController url:(NSString *)url completion:(TwitterLogInCompletion)completion;


/**
*  Triggers user logout with Twitter.
*  @param isRemoveCache Whether remove the cache cookie
*/
+ (void)logout:(BOOL)isRemoveCache;


@end
