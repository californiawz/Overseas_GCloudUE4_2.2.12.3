//
//  TwitterWrapperSession.h
//  TwitterWebDemo
//
//  Created by yvonneycai on 2020/3/17.
//  Copyright © 2020 MSDK. All rights reserved.
//

#import <Foundation/Foundation.h>

@class TwitterWrapperSession;

NS_ASSUME_NONNULL_BEGIN


/**
 *  Completion block called when user login succeeds or fails.
 *
 *  @param session  TwitterWrapperSession that contains user info
 *  @param error   Error that will be non nil if the authentication request failed.
 */
typedef void (^TwitterLogInCompletion)(TwitterWrapperSession * _Nullable session, NSError *_Nullable error);




/**
 *  TwitterWrapperSession represents a user's session.
 */
@interface TwitterWrapperSession : NSObject

- (instancetype) initWithAuthToken:(NSString *)token secret:(NSString *)secret userId:(NSString *)userId userName:(NSString *)userName;

- (NSString *) getAuthToken;

- (NSString *) getAuthTokenSecret;

- (NSString *) getUserId;

- (NSString *) getUserName;

@end

NS_ASSUME_NONNULL_END
