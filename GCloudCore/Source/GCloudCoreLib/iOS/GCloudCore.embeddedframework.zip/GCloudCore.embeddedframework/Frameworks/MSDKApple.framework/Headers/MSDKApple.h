///*
/*!
 * @Header MSDKApple.h
 * @Author lamarzhang(张庆贺)
 * @Version 1.0.0
 * @Date 2019/9/10
 * @Abstract 文件功能的声明
 *
 * @Module iTOP
 *
 * Copyright © company. All rights reserved.
 */

#import <MSDKApple/MSDKLoginApple.h>


#define MSDKApple_Version_String "5.10.001.5880"
#define MSDKApple_Version_Int 51001
#define GCLOUD_VERSION_MSDK_APPLE "GCLOUD_VERSION_MSDK_APPLE_5.10.001"
