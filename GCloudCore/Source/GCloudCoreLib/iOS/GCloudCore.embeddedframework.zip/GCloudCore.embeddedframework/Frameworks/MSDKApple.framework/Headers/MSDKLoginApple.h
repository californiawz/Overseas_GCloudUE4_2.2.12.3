/*!
* Copyright (C) 2019 THL A29 Limited, a company. All rights reserved.
*/


#import <Foundation/Foundation.h>
#import <MSDKCore/MSDKCore.h>

#define MSDK_APPLE_CHANNEL_ID     15
#define MSDK_APPLE_CHANNEL        "Apple"


/** 登录模块
 * - 命名规则：固定为 MSDKLogin + 渠道，如：MSDKLoginGarena
 * - 必须实现 MSDKLoginDelegate
 * - 必须实现单例模块，建议使用 SYNTHESIZE_SINGLETON_FOR_CLASS_HEADER + SYNTHESIZE_SINGLETON_FOR_CLASS_HEADER 宏处理
 */
@interface MSDKLoginApple : NSObject <MSDKLoginDelegate>

/** 插件必须是的单例的，建议使用 MSDK 提供的宏定义进行处理
 * 单例宏处理 - 头文件部分
 */
SYNTHESIZE_SINGLETON_FOR_CLASS_HEADER(MSDKLoginApple)

@end
