//
//  TDMASA.h
//  TDMASA
//
//  Created by JongXiao on 2021/8/10.
//  Copyright © 2021 TDataMaster. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for TDMASA.
FOUNDATION_EXPORT double TDMASAVersionNumber;

//! Project version string for TDMASA.
FOUNDATION_EXPORT const unsigned char TDMASAVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TDMASA/PublicHeader.h>


@interface TDMASA : NSObject

@end
