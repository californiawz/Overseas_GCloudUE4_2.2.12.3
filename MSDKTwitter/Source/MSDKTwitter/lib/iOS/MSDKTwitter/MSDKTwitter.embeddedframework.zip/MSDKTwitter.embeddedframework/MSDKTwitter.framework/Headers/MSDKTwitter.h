/*!
* Copyright (C) 2019 THL A29 Limited, a company. All rights reserved.
*/

#import <MSDKTwitter/MSDKLoginTwitter.h>
#import <MSDKTwitter/MSDKFriendTwitter.h>

#define MSDKTwitter_Version_String "5.30.001.7206"
#define MSDKTwitter_Version_Int 53001
#define GCLOUD_VERSION_MSDK_TWITTER "GCLOUD_VERSION_MSDK_TWITTER_5.30.001"

// Twitter 渠道配置项
#define MSDK_TWITTER_KEY    "TWITTER_KEY_IOS"
#define MSDK_TWITTER_SECRET "TWITTER_SECRET_IOS"

// Twitter 渠道名
#define MSDK_TWITTER_CHANNEL    "Twitter"

// Twitter 插件名
#define MSDK_TWITTER_PLUGIN_NAME   "MSDKTwitter"
