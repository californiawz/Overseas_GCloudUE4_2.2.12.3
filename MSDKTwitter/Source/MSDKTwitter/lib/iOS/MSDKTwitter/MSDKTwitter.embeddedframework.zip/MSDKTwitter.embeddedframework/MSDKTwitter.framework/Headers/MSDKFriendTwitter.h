/*!
* Copyright (C) 2019 THL A29 Limited, a company. All rights reserved.
*/

#import <Foundation/Foundation.h>
#import <MSDKCore/MSDKCore.h>

// 日志上报类型
#define TWITTER_FRIEND_REPORT_TYPE "TwitterFriend"

/**
 * Twitter 好友插件
 */
@interface MSDKFriendTwitter : NSObject <MSDKFriendDelegate>

/**
 * MSDK 中插件必须是单例的
 * 单例宏处理 - 头文件部分
 */
SYNTHESIZE_SINGLETON_FOR_CLASS_HEADER(MSDKFriendTwitter)

@end

