/*!
* Copyright (C) 2019 THL A29 Limited, a company. All rights reserved.
*/

#import <Foundation/Foundation.h>
#import <MSDKCore/MSDKCore.h>

// TDM 配置项
#define MSDK_TDM_SRC_ID "TDM_SRC_ID"

// TDM 调试开关
#define MSDK_TDM_DEBUG "TDM"

// TDM 渠道名
#define MSDK_TDM_CHANNEL "TDM"

// TDM 插件名
#define MSDK_TDM_PLUGIN_NAME    "MSDKTDM"

/**
 * TDM 事件上报插件
 */
@interface MSDKReportTDM : NSObject <MSDKReportDelegate>

/**
 * MSDK 中插件必须是单例的
 * 单例宏处理 - 头文件部分
 */
SYNTHESIZE_SINGLETON_FOR_CLASS_HEADER(MSDKReportTDM)

@end

