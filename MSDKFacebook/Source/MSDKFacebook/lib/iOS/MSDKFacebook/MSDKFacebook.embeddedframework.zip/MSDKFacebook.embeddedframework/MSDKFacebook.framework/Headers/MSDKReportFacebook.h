/*!
* Copyright (C) 2019 THL A29 Limited, a company. All rights reserved.
*/

#import <Foundation/Foundation.h>
#import <MSDKCore/MSDKCore.h>


/**
 * Facebook 事件上报插件
 */
@interface MSDKReportFacebook : NSObject <MSDKReportDelegate>

/** 插件必须是单例的
 * 单例宏处理 - 头文件部分
 */
SYNTHESIZE_SINGLETON_FOR_CLASS_HEADER(MSDKReportFacebook)

@end
