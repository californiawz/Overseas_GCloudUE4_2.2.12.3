/*!
* Copyright (C) 2019 THL A29 Limited, a company. All rights reserved.
*/

#import <MSDKFacebook/MSDKLoginFacebook.h>
#import <MSDKFacebook/MSDKFriendFacebook.h>
#import <MSDKFacebook/MSDKReportFacebook.h>

#define MSDKFacebook_Version_String "5.30.001.7206"
#define MSDKFacebook_Version_Int 53001
#define GCLOUD_VERSION_MSDK_FACEBOOK "GCLOUD_VERSION_MSDK_FACEBOOK_5.30.001"

#define MSDK_FACEBOOK_APP_ID        "FACEBOOK_APP_ID"
#define MSDK_FACEBOOK_DISPLAYNAME   "FACEBOOK_DISPLAYNAME"

#define FACEBOOK_LOGIN_MODE             "FACEBOOK_LOGIN_MODE"
#define FACEBOOK_LOGIN_MODE_GAME        @"Game"
#define FACEBOOK_LOGIN_MODE_APP         @"App"
#define FACEBOOK_GAME_MIN_SDK_VERSION    @"6.4.0"
