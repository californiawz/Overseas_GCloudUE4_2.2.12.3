//
//  MNAGHPublic.h
//  MNA
//
//  Created by Gavin on 04/01/2017.
//  Copyright © 2017 fu chunhui. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MNAKartinRet.h"

@interface MNAGHPublic : NSObject

+ (MNAGHPublic *) sharedInstance;

/**
 初始化方法
 
 @param qqAppid      应用手Q appid, 该应用的唯一标示
 @param isDebug      是否Debug，YES:打开Log开关，NO:关闭Log开关
 @param mZoneId      玩家大区id
 @param isReleaseEnv 是否为正式环境， YES:正式环境， NO:测试环境
 */
- (void) init:(NSString *)qqAppid
        debug:(BOOL)isDebug 
       zoneid:(int)mZoneId
   releaseEnv:(BOOL)isReleaseEnv;

/**
 初始化灯塔接口，调用后会对灯塔进行初始化
 */
- (void)configBeacon;

/**
 设置用户信息

 @param platform 平台类型， 于MSDK账号类型一致：
                ePlatform_None    0
                ePlatform_Weixin  1
                ePlatform_QQ      2
                ePlatform_WTLogin 3
                ePlatform_QQHall  4
                ePlatform_Guest   5
 @param openId 用户openid
 */
- (void) setUserName:(int) platform openId:(NSString *) openId;

/**
 管家查询网络质量

 @param tag 唯一的查询标识
 @param handler 返回查询结果结构体
 */
- (void) queryKartin:(NSString *)tag withGHCompletionHandler:(void (^)(MNAKartinRet *))handler;

/// 地域ipport测速
/// @param strTag 业务传入标识本次获取时延的请求
/// @param ipPortGroup 表示轮询测试的ipport组合，格式为IP1:PORT1_IP2:PORT2...
/// @param intervalMills 表示两次测试的间隔
/// @param count 表示需要轮询的次数，需求中是10次
/// @param timeoutMills 表示最后统计处理时，将超过timeoutMIlls的时延赋值为-1
/// @param handler 回调，主线程回调
- (void) getIpGroupDelays:(NSString *)strTag
                   ipPort:(NSString *)ipPortGroup
            intervalMills:(int)intervalMills
                    count:(int)count
             timeoutMills:(int) timeoutMills
  withGHCompletionHandler:(void (^)(NSString *))handler;

@end
