//
//  MNAKartinRet.h
//  MNA
//
//  Created by Gavin on 05/04/2017.
//  Copyright © 2017 fu chunhui. All rights reserved.
//

#import <Foundation/Foundation.h>

// 网络诊断成功
static const int kKartinFlagNormal = 0;
static NSString * const kKartinReasonNormal = @"成功";
static NSString * const kKartinReasonNormal_English = @"Success";

// 网络诊断请求云控无网络
static const int kKartinFlagNoNetFailed = -1;
static NSString * const kKartinReasonNoNetFailed = @"无网络";
static NSString * const kKartinReasonNoNetFailed_English = @"No Network";

// 网络诊断请求云控失败
static const int kKartinFlagCloudReqFailed = -2;
static NSString * const kKartinReasonCloudReqFailed = @"请求云控失败";
static NSString * const kKartinReasonCloudReqFailed_English = @"Request Control Fail";

// 网络切变
static const int kKartinFlagNetworkChanged = -4;
static NSString * const kKartinReasonNetworkChanged = @"查询过程网络类型切换";
static NSString * const kKartinReasonNetworkChanged_English = @"Network Changed";

// 2G网络
static const int kKartinFlagIs2GNetwork = -5;
static NSString * const kKartinReasonIs2GNetwork = @"2G网络下网速差";
static NSString * const kKartinReasonIs2GNetwork_English = @"2G Network";

// 卡顿请求CDN Master 失败
static const int KARTIN_FLAG_CDN_MASTER_FAILED = -2;
static NSString * const KARTIN_REASON_CDN_MASTER_FAILED = @"请求Master失败";
static NSString * const KARTIN_REASON_CDN_MASTER_FAILED_English = @"Request Master Fail";

// 卡顿其他原因flag
static const int KARTIN_FLAG_OTHER_REASON = -1000;
static NSString * const KARTIN_REASON_OTHER_REASON = @"其他情况";
static NSString * const KARTIN_REASON_OTHER_REASON_English = @"Other Reason";

@interface MNAKartinRet : NSObject

// 查询标识
@property (nonatomic, assign) int flag;
// 错误描述
@property (nonatomic, strong) NSString * desc;
// 查询tag
@property (nonatomic, strong) NSString * tag;
// 1、当时网络类型
@property (nonatomic, assign) int jump_network;
// 2、信号强度显示
@property (nonatomic, assign) int jump_signal;
// 3、信号强度状态显示
@property (nonatomic, assign) int signal_status;
// 4、信号前度desc
@property (nonatomic, strong) NSString * signal_desc;
// 5、ping路由延迟
@property (nonatomic, assign) int jump_router;
// 6、ping状态，取值0和1
@property (nonatomic, assign) int router_status;
// 7、ping 描述
@property (nonatomic, strong) NSString * router_desc;
// 8、宽带出口时延(jump_proxy, jump_edge)
@property (nonatomic, assign) int jump_export;
// 9、宽带出口和基站出口状态
@property (nonatomic, assign) int export_status;
// 10、宽带出口和基站出口描述
@property (nonatomic, strong) NSString * export_desc;
// 11、wifi终端数状态
@property (nonatomic, assign) int jump_terminal;
// 12、wifi终端数状态
@property (nonatomic, assign) int terminal_status;
// 13、wifi终端数描述
@property (nonatomic, strong) NSString * terminal_desc;
// 14、到代理延迟
@property (nonatomic, assign) int jump_proxy;
// 15、到边缘节点延迟jump_proxy
@property (nonatomic, assign) int jump_edge;
// 16、到直连测速节点延迟
@property (nonatomic, assign) int jump_direct;
// 17、直连测速节点状态
@property (nonatomic, assign) int direct_status;
// 18、直连测速节点描述
@property (nonatomic, strong) NSString * direct_desc;
// 19、网卡状态，0表示绿色网卡无问题；1表示红色网卡有问题
@property (nonatomic, assign) int netinfo_status;
@property (nonatomic, strong) NSString * netinfo_desc;
// 网络星级
@property (nonatomic, assign) int network_star;

@end
