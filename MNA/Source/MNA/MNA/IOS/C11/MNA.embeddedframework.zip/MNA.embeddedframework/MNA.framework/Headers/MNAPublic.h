//
//  MNAPublic.h
//  MNAPublic
//
//  Created by fu chunhui on 2018/1/4.
//  Copyright © 2018年 曹爽. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MNAObserver.h"

/// sdk版本号
static NSString * const MNA_VERSION = @"7.5.40i";

class MNAPublic {
private:
    static MNAPublic * m_pInst;
    MNAPublic();
    ~MNAPublic();
    
public:
    static MNAPublic * GetInstance();
    /**
     初始化

     @param appid           应用手Q appid，唯一标识该应用
     @param isDebug         是否打开MNA日志开关，true：打开Log开关，false：关闭Log开关
     @param zoneid          玩家大区id
     @param isReleaseEnv    是否为正式环境，true：正式环境，false：测试环境
     @param isBatteryNotify 是否使用电量回调，true：使用，false：不使用
     @param tCloudKey       腾讯云Key，非腾讯云业务填@""或者nil即可
     */
    void MNAInit(const char * appid, bool isDebug, int zoneid, bool isReleaseEnv, bool isBatteryNotify, const char * tCloudKey);
    
    void MNAInit(const char * appid, bool isDebug, int zoneid, bool isReleaseEnv, bool isBatteryNotify, int reportChannelType, const char * tCloudKey);
    
    void MNAGoBack();
    
    void MNAGoFront();
    
    /// Application.Quit接口调用
    void MNAQuit();
    
    /**
     设置用户信息
     
     @param platform   平台类型，与MSDK账号类型一致：
                         ePlatform_None      0
                         ePlatform_Weixin    1
                         ePlatform_QQ        2
                         ePlatform_WTLogin   3
                         ePlatform_QQHall    4
                         ePlatform_Guest     5
     @param openId     用户openid
     */
    void MNASetUserName(int platform, const char * openId);
    
    /**
     设置用户信息
     
     @param platform   平台类型，与MSDK账号类型一致：
                         ePlatform_None      0
                         ePlatform_Weixin    1
                         ePlatform_QQ        2
                         ePlatform_WTLogin   3
                         ePlatform_QQHall    4
                         ePlatform_Guest     5
     @param openId     用户openid
     @param userId     userId
     @param worldId    worldId
     */
    void MNASetUserNameWithUserID(int platform, const char * openId, const char * userId, const char * worldId);
    
    /**
     设置大区ID
     
     @param zoneid 玩家大区id
     */
    void MNASetZoneId(int zoneid);
    
    /**
     开始加速

     @param vip 游戏服务器地址（ip或者域名，强烈建议使用ip）
     @param vport 游戏服务器端口
     @param htype hook参数类型
     @param module hook模块，安卓下有效，ios下暂未使用
     @param zoneid 玩家大区id
     @param stopMNA 默认值为0，为1表示强制关闭加速功能，保留网络诊断功能。
     @param timeout startSpeed超时时间
     @param pvpid 对局id
     */
    void MNAStartSpeed(const char * vip, int vport, int htype, const char * module, int zoneid, int stopMNA, const char * pvpid, int timeout);
    
    /**
     开始加速（是否强制qos）

     @param vip 游戏服务器地址（ip或者域名，强烈建议使用ip）
     @param vport 游戏服务器端口
     @param htype hook参数类型
     @param module hook模块，安卓下有效，ios下暂未使用
     @param zoneid 玩家大区id
     @param stopMNA 默认值为0，为1表示强制关闭加速功能，保留网络诊断功能。
     @param timeout startSpeed超时时间
     @param pvpid 对局id
     @param forceMobileQOS 是否强制启动qos
     */
    void MNAStartSpeed(const char * vip, int vport, int htype, const char * module, int zoneid, int stopMNA, const char * pvpid, int timeout, int forceMobileQOS);
    
    /*
     设置对局中的测速ip，可以传域名
     */
    void MNASetPvpSpeedIp(const char *speedIp, int port);
    
    /*
     局中开启qos
     */
    void MNAStartMobileQos(int forceqos, int delay);
    
    /**
     强行关闭加速

     @param vip     游戏服务器地址，和MNAPublicStartSpeed参数保持一致
     @param vport   游戏服务器端口，和MNAPublicStartSpeed参数保持一致
     */
    void MNAStopMNA(const char * vip, int vport);
    
    /**
     结束加速
     
     @param vip     游戏服务器地址，和MNAPublicStartSpeed参数保持一致
     @param vport   游戏服务器端口，和MNAPublicStartSpeed参数保持一致
     */
    void MNAEndSpeed(const char * vip, int vport);
    
    /**
     结束加速, 上报额外信息extrainfo

     @param domain    服务器地址
     @param vport     服务器端口
     @param extrainfo 额外信息
     */
    void MNAEndSpeed(const char *domain, int vport, const char *extrainfo);
    
    /**
     结束加速, 上报额外信息extrainfo, gameWin是否胜利

     @param domain    服务器地址
     @param vport     服务器端口
     @param extrainfo 额外信息
     */
    void MNAEndSpeed(const char *domain, int vport, const char *extrainfo, int gameWin);
    
    /**
     网络诊断
     
     @param tag 标识每一次查询的id
     */
    void MNARealTimeQuery(const char * tag);
    
    /**
     网络诊断回调
     
     @param observer MNAObserver回调实例
     */
    void MNASetObserver(MNAObserver * observer);
    
    /**
     中途重新设置业务ip
     @param gameip 设置新的业务ip
     */
    void MNASetGameIp(const char *gameip);
    
    /**
    中途重新设置业务ip, port
    @param gameip 设置新的业务ip, port
    */
    void MNASetGameIPWithPort(const char *gameip, int port);
    
    /// AOV业务希望在加速后，代理转发给游戏服务器的内网IP，免去转发给外网IP时需要再走一遍外网网卡的过程。代理和游戏服务器部署在同一机房
    /// @param gameIp 游戏ip
    /// @param port 游戏端口
    /// @param localIp 本地ip
    /// @param localPort 本地port
    void MNASetGameIPWithLocalIP(const char *gameIp, int port, const char *localIp, int localPort);
    
    /**
     获取当前网络时延值
     
     @param vip     游戏服务器地址
     @param vport   游戏服务器端口
     @return        当前网络时延，返回格式：state;netType;delay
                     state: 0_直连，1_加速
                     netType: 0_无网络，1_2G，2_3G，3_4G，4_wifi
                     delay: 当前时延(ms)
     */
    const char * MNAGetSpeedInfo(const char * vip, int vport);
    
    /**
     QOS工作情况
     
     @return     1 保障成功
                 0 保障失败(默认值)
                 -1 非4G
                 -2 不满足保障条件
                 -3 云控配置关闭
                 -4 云控返回errno非0
                 -5 解析云控数据失败
                 -6 获取本地ip失败
                 -7 运营商返回errno非0
                 -8 解析运营商数据失败
     */
    int MNAIsQOSWork();
    
    /**
     获取电量接口
     
     @return 电量百分比
     */
    int MNAGetBatteryLevel();
    
    /**
     获取电量百分比及充放电状态接口
     
     @return 电量百分比及充放电状态。长度固定为2，以分号分隔，第一个值为电量百分比，第二个值为充放电状态（0为放电，1为充电）
     */
    const char * MNAGetBatteryLevelAndCharging();
    
    /**
     获取QOS的sid
     
     @return sessionId
     */
    const char * MNAGetQOSSid();
    
    /**
     Unity 存储游戏数据方法
     
     @param fps    fps数据
     @param move   move数据
     @param click  点击数据
     */
    void MNAAddFpsData(const char * fps, const char * move, const char * click);
    
    /**
     比赛模式设置接口, 这个方法需在Init方法前调用
     
     @param isMatchMode YES表示为游戏比赛模式
     */
    void MNASetGameMode(bool isMatchMode);
    
    /**
     比赛模式接口，用于传递业务测速延迟值

     @param delay 业务测速延迟值
     */
    void MNASetGameDelay(int delay);
    
    /**
     暂停游戏接口：暂停游戏测速，数据上报到后台
     */
    void MNAPauseBattle();
    
    /**
     重新开始对战游戏接口：重新开始游戏测速
     */
    void MNAResumeBattle();
    
    /**
     设置下载带宽
     
     @param bandwidthValue  下载速率(KB/s)_下载速率(KB/s)_下载速率(KB/s)...
     @param totalSize       本次下载总大小(KB)
     @param elapseTime      本次下载耗时(s)
     @param maxBandValue    最大下载速率(KB/s)
     */
    void MNASetBandwidth(const char * bandwidthValue, const char * totalSize, const char * elapseTime, const char * maxBandValue);
    
    void MNAEnterMapLoading();
    
    /**
     快速返回基本的网络信息
     */
    void MNAQueryNetwork(bool isGetNetcardInfo, bool isGetRouterDelay, bool isGetEdgeDelay);
    
    /**
     王者查询路由信息接口
     */
    void MNAQueryRouter(const char * tag);
    
    /**
     wifi/4g切换
     */
    void MNAToggleW2M(int bufferScore, bool playerSetting);
    
    /**
     传递游戏信息
     */
    void MNATransportInfo(int msgType, const char * msg);
    
    /**
    加强诊断功能接口
    */
    void MNAQueryPreciseKartin(int64_t curServTime, int64_t pvpDurationTime, const char * triggerDelay);
    
    /**
    判断当前是否处于腾讯手游加速器加速状态
    
    @return     true/false
    */
    bool IsMNAVPNOpen();
    
    /**
    判断当前是否有vpn开启
    
    @return     true/false
    */
    bool IsAnyVpnOpen();
    
    /**
    设置是否为海外业务，true为海外业务，false为国内业务
    */
    void MNASetOverseaGame(bool isOversea);
    
    /// 设置云控域名
    /// @param controlDomain 域名
    /// @param controlPort 端口
    void MNASetControlDomain(const char *controlDomain, int controlPort);
    
    /// 地域ipport测速
    /// @param tag 业务传入标识本次获取时延的请求
    /// @param ipPortGroup 表示轮询测试的ipport组合，格式为IP1:PORT1_IP2:PORT2...
    /// @param intervalMills 表示两次测试的间隔
    /// @param count 表示需要轮询的次数，需求中是10次
    /// @param timeoutMills 表示最后统计处理时，将超过timeoutMIlls的时延赋值为-1
    void MNAGetIpGroupDelays(const char *tag, const char *ipPortGroup, int intervalMills, int count, int timeoutMills);
    
    /// 地域ipport测速
    /// @param tag 业务传入标识本次获取时延的请求
    /// @param ipPortGroup 表示轮询测试的ipport组合，格式为IP1:PORT1_IP2:PORT2...
    /// @param intervalMills 表示两次测试的间隔
    /// @param count 表示需要轮询的次数，需求中是10次
    /// @param timeoutMills 表示最后统计处理时，将超过timeoutMIlls的时延赋值为-1
    void MNAGetIpGroupDelaysForTest(const char *tag, const char *ipPortGroup, int intervalMills, int count, int timeoutMills);
    
    /// 地域ipport测速
    /// @param tag 业务传入标识本次获取时延的请求
    /// @param ipPortGroup 表示轮询测试的ipport组合，格式为IP1:PORT1_IP2:PORT2...
    /// @param intervalMills 表示两次测试的间隔
    /// @param count 表示需要轮询的次数，需求中是10次
    /// @param timeoutMills 表示最后统计处理时，将超过timeoutMIlls的时延赋值为-1
    void MNAGetIpGroupDelaysUseTCP(const char *tag, const char *ipPortGroup, int intervalMills, int count, int timeoutMills);
    
    /// 地域ipport测速
    /// @param tag 业务传入标识本次获取时延的请求
    /// @param ipPortGroup 表示轮询测试的ipport组合，格式为IP1:PORT1_IP2:PORT2...
    /// @param intervalMills 表示两次测试的间隔
    /// @param count 表示需要轮询的次数，需求中是10次
    /// @param timeoutMills 表示最后统计处理时，将超过timeoutMIlls的时延赋值为-1
    void MNAGetIpGroupDelaysForTestUseTCP(const char *tag, const char *ipPortGroup, int intervalMills, int count, int timeoutMills);
    
    /// 绑定其他网络测速，受smobaSpeedReportBinding（新增的）控制上报次数，注意独立计数
    /// @param tag 业务传入标识本次获取时延的请求
    /// @param ipPortGroup 表示轮询测试的ipport组合，格式为IP1:PORT1_IP2:PORT2...
    /// @param intervalMills 表示两次测试的间隔
    /// @param count 表示需要轮询的次数，需求中是10次
    /// @param timeoutMills 表示最后统计处理时，将超过timeoutMIlls的时延赋值为-1
    void MNAGetIpGroupDelaysWithBinding(const char *tag, const char *ipPortGroup, int intervalMills, int count, int timeoutMills, int ipProto, int bindNetType);
    
    /// 设置绑定模式
    /// @param bindNetType 绑定类型
    /// @param useSaveFlow 是否节能
    void MNASetDualTunnelBindNetType(int bindNetType, bool useSaveFlow);
    
    /**
     * 用于设置是否通知demo更新，放在debug里面太危险了，仅用于MNA开发人员debug使用
     * @param flag 如果为true表明可以notify
    */
    void MNASetDebugNotify(bool flag);
    
    
    /// 双通道加速增加局前测速的判断逻辑
    /// @param isForceSpeed 是否强制加速
    void MNASetForceSpeed(bool isForceSpeed);
    
    /// 获取当前的网络类型（WiFi/4G/5G等）
    int MNAGetNetworkType();
    
    /// （Wi-Fi网络下）获取移动网络具体类型
    int MNAGetTelephonyType();
    
    /// sim卡开启数量, 返回值表示启用的SimCard数量_插入的SimCard数量, iOS暂时获取不到插入的SimCard数量
    const char * MNAGetMobileActiveSimCountInfo();
    
    /// 指针释放
    void MNAFreeMem(char *ptr);
    
    /// ping网关
    /// @param tag 业务传入标识本次获取时延的请求
    /// @param intervalMills 两次ping的间隔
    /// @param count 次数
    /// @param pkgTimeoutMills ping包超时
    /// @param onlywifi 是否只在wifi下执行，如果是4G的话，直接返回flag不正常，中途有网络切变，也返回不正常
    void MNAPingGateway(const char *tag, int intervalMills, int count, int pkgTimeoutMills, bool onlywifi);
    
    /// ping指定ip
    /// @param tag 业务传入标识本次获取时延的请求
    /// @param ip 目标地址
    /// @param intervalMills 两次ping的间隔
    /// @param count 次数
    /// @param pkgTimeoutMills ping包超时
    /// @param onlyWifi 是否只在wifi下执行，如果是4G的话，直接返回flag不正常，中途有网络切变，也返回不正常
    void MNAPing(const char *ip, const char *tag, int intervalMills, int count, int pkgTimeoutMills, bool onlyWifi);
    
    /// 返回上一次5秒测速的延迟值，没有开始加速或者结束加速时返回-100
    int MNAGetSpeedDelay();
    
    /// 4G通道的实时开启和关闭
    void MNASetAuxFlowEnable(bool enableSend, bool enableRecv);
};
