//
//  MNAObserver.h
//  MNA
//
//  Created by fu chunhui on 2018/1/5.
//  Copyright © 2018年 曹爽. All rights reserved.
//

#ifndef MNAObserver_h
#define MNAObserver_h

class MNAObserver {
public:

    virtual void OnStartSpeedNotify(const char * startSpeedString) = 0;
    virtual void OnQueryKartinNotify(const char * queryKartinString) = 0;
    virtual void OnBatteryChangedNotify(const char * batteryChangedString) = 0;
    virtual void OnStartRecord(const char * startRecordString) = 0;
    virtual void OnQueryNetworkNotify(const char * networkInfoString) = 0;
    virtual void OnQueryRouterNotify(const char * routerRetString) = 0;
    virtual void OnBindNotify(const char * bindString) = 0;
    virtual void OnGetIpGroupDelaysNotify(const char *delayString) = 0;
    virtual void OnGetIpGroupDelaysTCPNotify(const char *delayString) = 0;
    virtual void OnGetIpGroupDelaysWithBindingNotify(const char *delayString) = 0;
    virtual void OnQueryPreciseKartinNotify(const char *kartinString) = 0;
    virtual void OnPingNotify(const char *pingString) = 0;
    virtual ~MNAObserver() {};
};

#endif /* MNAObserver_h */
